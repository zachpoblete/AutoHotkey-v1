Accelerated Scrolling script for AutoHotKey
V1.3
by BoffinbraiN

For full details, and to get updates and support, visit the forum thread at:
http://www.autohotkey.com/forum/viewtopic.php?p=323193

This archive contains:
- The source file (you need AutoHotKey installed to run this)
- The compiled exe (the password is 'ahk')
- A text file 'Lines.txt' containing 10,000 lines of 100x100 triangles, to test wheel acceleration.
